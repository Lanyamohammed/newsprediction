import pandas as pd
import re
import string
from flask import Flask, request, jsonify
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

# Preprocess function
def preprocess_text(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = re.sub(r'\d+', '', text)
    text = text.strip()
    return text

# Load data
fake_df = pd.read_csv('Fake.csv')
real_df = pd.read_csv('True.csv')

fake_df['label'] = 0
real_df['label'] = 1

data = pd.concat([fake_df, real_df], ignore_index=True)
data = data.sample(frac=1).reset_index(drop=True)  # shuffle

data['text'] = data['text'].astype(str).apply(preprocess_text)

# Visualization: Distribution of fake vs real news
sns.countplot(data=data, x='label')
plt.title('Distribution of Fake (0) and Real (1) News')
plt.xlabel('Label (0=Fake, 1=Real)')
plt.ylabel('Number of Articles')
plt.show()

X = data['text']
y = data['label']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

vectorizer = TfidfVectorizer(stop_words='english', max_features=5000)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

model = LogisticRegression(max_iter=1000)
model.fit(X_train_vec, y_train)

y_pred = model.predict(X_test_vec)
print("Accuracy:", accuracy_score(y_test, y_pred))

# Save model and vectorizer for reuse
joblib.dump(model, 'model.joblib')
joblib.dump(vectorizer, 'vectorizer.joblib')

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    if not data or 'text' not in data:
        return jsonify({'error': 'Missing text field'}), 400

    text = preprocess_text(data['text'])
    vectorizer_loaded = joblib.load('vectorizer.joblib')
    model_loaded = joblib.load('model.joblib')

    vec = vectorizer_loaded.transform([text])
    prediction = model_loaded.predict(vec)[0]
    label = 'Real' if prediction == 1 else 'Fake'

    return jsonify({'prediction': label})

if __name__ == '__main__':
    app.run(port=5000)
